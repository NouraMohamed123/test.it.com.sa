<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Mode</title>
    <link id="worktick-theme" rel="stylesheet" href="{{ asset('assets/styles/css/themes/lite-purple.min.css') }}">

</head>
<body>
    <div class="container">
        <h1 class="text-center title">Application is down for maintenance</h1>
        <div class="text-center">
            <a class="btn btn-primary" href="/1630542a-246b-4b66-afa1-dd72a4c43515">Click Here to Fix This issue</a>
         </div>
    </div>
</body>
</html>