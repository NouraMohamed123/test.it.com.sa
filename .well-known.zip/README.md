# Version 1.0 - 25-03-2022

-   Initial version

# Version 1.1 - 31-03-2022

-   Fixed : Bugs fixes

# Version 1.2 - 16-04-2022

-   Fixed : Bugs fixes

# Version 1.3

-   Change Time Zone from Settings
-   Install/Upload Modules
-   Documentation Updated
-   Bugs fixes

