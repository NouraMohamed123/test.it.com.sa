
<?php $__env->startSection('main-content'); ?>
<?php $__env->startSection('page-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/datepicker.min.css')); ?>">


<?php $__env->stopSection(); ?>

<div class="breadcrumb">
    <h1><?php echo e(__('translate.Attendances')); ?></h1>
    <ul>
        <li><a href="/report/attendance"><?php echo e(__('translate.Attendance_Report')); ?></a></li>
        <li><?php echo e(__('translate.Attendances')); ?></li>
    </ul>
</div>

<div class="separator-breadcrumb border-top"></div>

<div class="row" id="section_Attendance_report">
    <div class="col-md-12">
        <div class="card text-left">
            <div class="card-header text-right bg-transparent">

                <a class="btn btn-primary btn-md m-1" id="Show_Modal_Filter"><i class="i-Filter-2 text-white mr-2"></i>
                    <?php echo e(__('translate.Filter')); ?></a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="ul-contact-list" class="display table Attendance_datatable">
                        <thead>
                            <tr>
                                <th><?php echo e(__('translate.Employee')); ?></th>
                                <th><?php echo e(__('translate.Company')); ?></th>
                                <th><?php echo e(__('translate.Date')); ?></th>
                                <th><?php echo e(__('translate.Time_In')); ?></th>
                                <th><?php echo e(__('translate.Time_Out')); ?></th>
                                <th><?php echo e(__('translate.Time_Late')); ?></th>
                                <th><?php echo e(__('translate.Depart_early')); ?></th>
                                <th><?php echo e(__('translate.Overtime')); ?></th>
                                <th><?php echo e(__('translate.Work_Duration')); ?></th>
                                <th><?php echo e(__('translate.Rest_Duration')); ?></th>
                                <th><?php echo e(__('translate.Status')); ?></th>
                            </tr>
                        </thead>


                    </table>
                </div>
            </div>
        </div>
        <!-- Modal Filter Attendance -->
        <div class="modal fade" id="Filter_Attendance_Modal" tabindex="-1" role="dialog"
            aria-labelledby="Filter_Attendance_Modal" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo e(__('translate.Filter')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form method="POST" id="Filter_Attendance_report">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="col-md-4">
                                    <label for="employee_id" class="ul-form__label"><?php echo e(__('translate.Employee')); ?>

                                    </label>
                                    <select name="employee_id" id="employee_id" class="form-control">
                                        <option value="0"><?php echo e(__('translate.All')); ?></option>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->username); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label for="start_date" class="ul-form__label"><?php echo e(__('translate.From_Date')); ?>

                                    </label>
                                    <input type="text" class="form-control date" name="start_date" id="start_date"
                                        placeholder="<?php echo e(__('translate.From_Date')); ?>" value="">
                                </div>

                                <div class="col-md-4">
                                    <label for="end_date" class="ul-form__label"><?php echo e(__('translate.To_Date')); ?> </label>
                                    <input type="text" class="form-control date" name="end_date" id="end_date"
                                        placeholder="<?php echo e(__('translate.To_Date')); ?>" value="">
                                </div>


                            </div>

                            <div class="row mt-3">

                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-outline-success">
                                        <?php echo e(__('translate.Filter')); ?>

                                    </button>

                                    <button id="Clear_Form" class="btn btn-outline-danger">
                                        <?php echo e(__('translate.Clear')); ?>

                                    </button>
                                </div>

                            </div>


                        </form>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

<script src="<?php echo e(asset('assets/js/vendor/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/datatables.script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/datepicker.min.js')); ?>"></script>

<script type="text/javascript">
    $(function () {
      "use strict";

      $(document).ready(function () {

            $("#start_date,#end_date").datepicker({
                format: 'yyyy-mm-dd',
                changeMonth: true,
                changeYear: true,
                autoclose: true,
                todayHighlight: true,
            });
            var lastDate = new Date();
            $("#end_date").datepicker("setDate" , lastDate);
            lastDate.setDate(lastDate.getDate() - 365);
            $("#start_date").datepicker("setDate" , lastDate);

        
        });


        // init datatable.
        Attendance_datatable();
        function Attendance_datatable(start_date ='' ,end_date ='', employee_id=''){
            var dataTable = $('#ul-contact-list').DataTable({
                processing: true,
                responsive: true,
                serverSide: true,
                autoWidth: false,
                pageLength: 10,
                "order": [[ 0, "desc" ]],
                ajax: {
                    url: "<?php echo e(route('attendance_report_index')); ?>",
                    data: {
                        start_date: start_date === null?'':start_date,
                        end_date: end_date === null?'':end_date,
                        employee_id: employee_id == '0'?'':employee_id,
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                },

                columns: [
                    {data: 'employee.username', name: 'Employee'},
                    {data: 'company.name', name: 'Company'},
                    {data: 'date', name: 'Date'},
                    {data: 'clock_in', name: 'Time In'},
                    {data: 'clock_out', name: 'Time Out'},
                    {data: 'late_time', name: 'Time Late'},

                    {data: 'depart_early', name: 'Depart early'},
                    {data: 'overtime', name: 'Overtime'},
                    {data: 'total_work', name: 'Work Duration'},
                    {data: 'total_rest', name: 'Rest Duration'},
                    {data: 'status', name: 'Status'},
                ],
                dom: "<'row'<'col-sm-12 col-md-7'lB><'col-sm-12 col-md-5 p-0'f>>rtip",
                oLanguage:
                    { 
                    sLengthMenu: "_MENU_", 
                    sSearch: '',
                    sSearchPlaceholder: "Search..."
                },
                buttons: [
                {
                    extend: 'collection',
                    text: 'EXPORT',
                    buttons: [
                        'csv','excel', 'pdf', 'print'
                    ]
                }]
            });
        }

         // Clear Filter

         $('#Clear_Form').on('click' , function (e) {
            var lastDate = new Date();
            $("#end_date").datepicker("setDate" , lastDate);
            lastDate.setDate(lastDate.getDate() - 365);
            $("#start_date").datepicker("setDate" , lastDate);
            let employee_id = $('#employee_id').val('0');
            Attendance_datatable(start_date ='' ,end_date ='', employee_id);
        });

         // Show Modal Filter

        $('#Show_Modal_Filter').on('click' , function (e) {
            $('#Filter_Attendance_Modal').modal('show');
        });


         // Submit Filter

        $('#Filter_Attendance_report').on('submit' , function (e) {
            e.preventDefault();
            var start_date = $('#start_date').val();
            var end_date = $('#end_date').val();
            let employee_id = $('#employee_id').val();
      
            $('#ul-contact-list').DataTable().destroy();
            Attendance_datatable(start_date, end_date, employee_id);

            $('#Filter_Attendance_Modal').modal('hide');
           
               
        });
       
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/it/public_html/test.it.com.sa/resources/views/report/attendance_report.blade.php ENDPATH**/ ?>